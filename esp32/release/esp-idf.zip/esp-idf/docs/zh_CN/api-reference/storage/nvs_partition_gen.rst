.. include:: /../../components/nvs_flash/nvs_partition_generator/README.rst
