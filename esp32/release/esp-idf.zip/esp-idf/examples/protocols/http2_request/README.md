# HTTP/2 Request Example

Established HTTP/2 connection with https://http2.golang.org
- Performs a GET on /clockstream
- Performs a PUT on /ECHO

