## SPI master example

This code displays a simple graphics with varying pixel colors on the 320x240 LCD on an ESP-WROVER-KIT board.

If you like to adopt this example to another type of display or pinout, check [manin/spi_master_example_main.c] for comments that explain some of implementation details.
