# I2S Example

### This example shows:

Init and using I2S module:
 
* Generate 100Hz triangle wave in a channel, and sine wave in another, with 36Khz sample rates. Change bits per sample every 5 seconds
     
* You can change bits per sample and sample rates with `i2s_set_clk`
     

