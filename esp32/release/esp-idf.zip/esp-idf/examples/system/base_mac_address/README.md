# Example: base mac address

This example illustrates how to get and set base MAC address.

