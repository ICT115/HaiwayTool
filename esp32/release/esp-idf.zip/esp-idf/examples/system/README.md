# System Examples

Configuration and management of memory, interrupts, WDT (watchdog timer), OTA (over the air updates), deep sleep and logging.

See the [README.md](../README.md) file in the upper level [examples](../) directory for more information about examples.
