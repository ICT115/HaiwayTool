# Example: task_watchdog

This test code shows how to initialize the task watchdog, add tasks to the
watchdog task list, feeding the tasks, deleting tasks from the watchdog task
list, and deinitializing the task watchdog.


### Test:

Program should run without error. Comment out "esp_task_wdt_feed()" to observe
a watchdog timeout.

