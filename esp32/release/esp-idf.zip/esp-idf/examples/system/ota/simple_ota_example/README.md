# Simple OTA example

This example is based on `http_firmware_upgrade` component's APIs.

## Configuration

Refer README.md in the parent directory for setup details