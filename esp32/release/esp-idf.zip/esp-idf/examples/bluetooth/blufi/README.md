ESP-IDF Blufi demo
=======================

This is the demo for bluetooth config wifi connection to ap.

attentions:
    1. Please use the BLEDEMO APK
    2. As the GATTServer start a litte slowly, so Please Wait for a period, then use apk scan the apk util find a random address devices named Espressif_008
    3. Just a unstable version..

