ESP-IDF iBeacon demo
========================
This example demonstrates iBeacon-compatible BLE advertising, and scanning of iBeacons.
- IBEACON_SENDER: demo to send iBeacon-compatible advertising data.
- IBEACON_RECEIVER: demo to receive and resolve iBeacon advertising data.

iBeacon is a trademark of Apple Inc.

Before building devices which use iBeacon technology, visit https://developer.apple.com/ibeacon/ to obtain a license.
