# Bluetooth Examples

Note: To use examples in this directory, you need to have Bluetooth enabled in configuration. Run `make menuconfig`, go to `Component config` and verify if you see `[*] Bluetooth`. If not - enable it and save.

See the [README.md](../README.md) file in the upper level [examples](../) directory for more information about examples.
