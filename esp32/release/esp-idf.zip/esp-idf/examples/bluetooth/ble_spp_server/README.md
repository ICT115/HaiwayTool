## ESP-IDF GATT SERVER SPP demo

For description of this application please refer to [ESP-IDF GATT CLIENT SPP demo](../ble_spp_client/README.md)
